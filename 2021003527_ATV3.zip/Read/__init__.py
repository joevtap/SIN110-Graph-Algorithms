from .get_input import read_instance
